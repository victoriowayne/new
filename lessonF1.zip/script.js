VANTA.BIRDS({
    el: "body",
    mouseControls: true,
    touchControls: true,
    gyroControls: false,
    minHeight: 200.00,
    minWidth: 200.00,
    scale: 1.00,
    scaleMobile: 1.00,
    backgroundColor: 0x5e4472
  })


// Подключить все три скрипта в html 
// <script src="three.min.js"></script>
// <script src="vanta.birds.min.js"></script>
// <script src="script.js"></script>